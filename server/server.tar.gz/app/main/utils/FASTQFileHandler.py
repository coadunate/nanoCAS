import json
import logging
import os
import subprocess
import sys
import glob
from watchdog.events import FileSystemEventHandler
from .LinuxNotification import LinuxNotification

logger = logging.getLogger('micas')

class FASTQFileHandler(FileSystemEventHandler):

    def __init__(self, app_loc):
        self.app_loc = app_loc
        self.num_files_classified = 0

    def on_moved(self, event):
        self.on_any_event(event)

    def on_any_event(self, event):
        if event.src_path.endswith((".fastq", ".fasta")):
            logger.debug(f'File Event ({event.event_type}), Path: {event.src_path}')
            self.process_fastq_fasta_file(event.src_path)
        else:
            logger.debug(f"Non-FASTQ/FASTA file generated in MINION location: {event.src_path}")

    def process_fastq_fasta_file(self, src_path):
        # Paths for minimap2 output and final output files
        minimap2_output = os.path.join(self.app_loc, 'minimap2', 'runs', f'{os.path.basename(src_path)}.out.paf')
        final_output = os.path.join(self.app_loc, 'minimap2', 'final.out.paf')

        # Identify the index file
        index_file = self.get_index_file()
        if not index_file:
            return

        # Run minimap2
        cmd = f'minimap2 {index_file} {src_path} -o {minimap2_output}'
        logger.debug(f"Running command: {cmd}")
        proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = proc.communicate()

        # Check if minimap2 was successful and if the output file is not empty
        if proc.returncode != 0 or not os.path.exists(minimap2_output) or os.path.getsize(minimap2_output) == 0:
            logger.error(f"Error: Minimap2 failed or produced an empty output for {src_path}")
            if stderr:
                logger.error(stderr.decode())
            return

        logger.debug(f"Minimap2 successful for {src_path}, processing output...")
        self.process_minimap2_output(minimap2_output, final_output)

    def get_index_file(self):
        files = glob.glob(os.path.join(self.app_loc, 'database', '*.mmi'))
        if not files:
            logger.error("Error: Database not found! No MMI files found at database location")
            sys.exit(1)
        return files[0]

    def process_minimap2_output(self, minimap2_output, final_output):
        # Read the first line of minimap2 output
        with open(minimap2_output, 'r') as f:
            line = f.readline().strip()

        if not line:
            logger.error(f"Error: Minimap2 output file {minimap2_output} is empty.")
            return

        minimap2_output_line = line.split("\t")
        if len(minimap2_output_line) < 10:
            logger.error(f"Error: Minimap2 output file {minimap2_output} has an unexpected format.")
            return

        match_alert_header = minimap2_output_line[5]
        num_match = int(minimap2_output_line[9])
        tot_len = int(minimap2_output_line[6])
        percent_match_value = (num_match / tot_len) * 100

        logger.debug(f"Minimap2 Alignment, Header: {match_alert_header}, Matches: {num_match}, Total Length: {tot_len}, % Match: {percent_match_value:.2f}")

        # Update alert information
        self.update_alert_info(match_alert_header, percent_match_value)

        # Handle output files
        self.handle_output_files(minimap2_output, final_output)

    def update_alert_info(self, match_alert_header, percent_match_value):
        alertinfo_cfg_file = os.path.join(self.app_loc, 'alertinfo.cfg')
        with open(alertinfo_cfg_file, 'r') as f:
            alertinfo_cfg_data = json.load(f)

        queries = alertinfo_cfg_data.get("queries", [])
        device = alertinfo_cfg_data.get("device", "")

        for query in queries:
            if match_alert_header in query.get("header", ""):
                query["current_value"] = percent_match_value
                threshold_str = query.get("threshold", "")
                if threshold_str and threshold_str.strip():  # Check if non-empty
                    try:
                        threshold = float(threshold_str)
                        if threshold <= percent_match_value:
                            alert_str = (
                                f"Alert: The named taxa {query['name']} was detected to be at a concentration of "
                                f"{percent_match_value:.4f}%. This is above the set threshold of {threshold:.4f}%.")
                            logger.critical(alert_str)
                            if device:
                                LinuxNotification.send_notification(device, alert_str)
                    except ValueError:
                        logger.error(
                            f"Invalid threshold value for query {query.get('name', 'unknown')}: {threshold_str}")
                else:
                    logger.warning(f"Threshold missing or empty for query {query.get('name', 'unknown')}")

        with open(alertinfo_cfg_file, 'w') as f:
            json.dump(alertinfo_cfg_data, f, indent=4)

    def handle_output_files(self, minimap2_output, final_output):
        if os.path.isfile(final_output):
            logger.debug(f"Appending to existing final output file: {final_output}")
            with open(final_output, "a+") as f:
                f.writelines(open(minimap2_output).readlines())
        else:
            logger.debug(f"Renaming minimap2 output file to final output: {final_output}")
            os.rename(minimap2_output, final_output)

        # Increase the count of classified files
        self.num_files_classified += 1